package model;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.Entity;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;


@Entity
@Table(name = "PlansPrePaid")
public class PrePaidPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @NotEmpty(message = "Provide plan name")
    private String planName;

    @NotEmpty(message = "Provide plan price")
    private int planPrice;

    public PrePaidPlan(){}

    @Override
    public String toString() {
        return "PrePaidPlan{" +
                "id=" + id +
                ", planName='" + planName + '\'' +
                ", planPrice='" + planPrice + '\'' +
                '}';
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public int getPlanPrice() {
        return planPrice;
    }

    public void setPlanPrice(int planPrice) {
        this.planPrice = planPrice;
    }

    public PrePaidPlan(@NotEmpty(message = "Provide plan name") String planName, @NotEmpty(message = "Provide plan price") int planPrice) {
        this.planName = planName;
        this.planPrice = planPrice;
    }
}
