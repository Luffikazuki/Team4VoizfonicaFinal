package model;


import org.springframework.data.repository.CrudRepository;


public interface PrePaidPlanRepository extends CrudRepository<PrePaidPlan,Integer> {

}
